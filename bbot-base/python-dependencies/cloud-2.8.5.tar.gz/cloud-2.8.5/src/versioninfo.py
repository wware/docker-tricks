# This file defines versioning information
release_version="2.8.5"
git_revision="40423641c60fe244a46791fdce7afa7642e17d0d"

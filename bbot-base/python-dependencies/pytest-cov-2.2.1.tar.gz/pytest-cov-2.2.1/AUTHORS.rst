Authors
=======

* Marc Schlaich - http://www.schlamar.org/
* Rick van Hattem - http://wol.ph/
* Buck Evan - https://github.com/bukzor
* Eric Larson - http://larsoner.com/
* Marc Abramowitz - http://marc-abramowitz.com/
* Thomas Kluyver - https://github.com/takluyver
* Guillaume Ayoub - http://www.yabz.fr/
* Federico Ceratto - http://firelet.net/
* Josh Kalderimis - http://blog.cookiestack.com/
* Ionel Cristian Mărieș - http://blog.ionelmc.ro
* Christian Ledermann - https://github.com/cleder

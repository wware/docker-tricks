=====
Usage
=====

To use remote-pdb in a project::

	import remote_pdb
